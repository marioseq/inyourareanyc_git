<?php
if( !defined('VPRO' ) )
	define( 'VPRO', true );
@ini_set('memory_limit', WP_MAX_MEMORY_LIMIT );
