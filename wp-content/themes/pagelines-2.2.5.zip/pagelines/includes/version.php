<?php 

// Internal build versions.

$platform_build = '2.2.5';

$free_build = '1.2.2';
